package com.ajay.interview_prep_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterviewPrepBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterviewPrepBackendApplication.class, args);
	}

}
