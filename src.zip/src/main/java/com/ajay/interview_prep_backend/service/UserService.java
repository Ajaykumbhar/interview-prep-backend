package com.ajay.interview_prep_backend.service;

import com.ajay.interview_prep_backend.dto.LoginRequest;
import com.ajay.interview_prep_backend.dto.RegisterRequest;
import com.ajay.interview_prep_backend.dto.UserResponse;
import com.ajay.interview_prep_backend.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private UserRepository userRepository;
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UserResponse register(RegisterRequest registerRequest) {
        UserResponse repsonse=new UserResponse();
        repsonse.
    }
    public String login(LoginRequest loginRequest) {
        return "login";
    }
    public String findByUserEmail(String email){
        return "findByEmail";
    }
}
